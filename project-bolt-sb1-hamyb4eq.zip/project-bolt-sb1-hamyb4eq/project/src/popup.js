import { ChatGPTClient } from './utils/chatgptClient.js';

const client = new ChatGPTClient();

document.addEventListener('DOMContentLoaded', async () => {
  const loginPrompt = document.getElementById('loginPrompt');
  const mainContent = document.getElementById('mainContent');
  const summarizeButton = document.getElementById('summarizeButton');
  const summary = document.getElementById('summary');
  const summaryContent = document.getElementById('summaryContent');
  const loading = document.getElementById('loading');
  const loginButton = document.getElementById('loginButton');

  // Initialize i18n
  document.querySelectorAll('[data-i18n]').forEach(element => {
    const key = element.getAttribute('data-i18n');
    element.textContent = chrome.i18n.getMessage(key);
  });

  // Check login status
  const isLoggedIn = await client.checkLoginStatus();
  loginPrompt.classList.toggle('hidden', isLoggedIn);
  mainContent.classList.toggle('hidden', !isLoggedIn);

  loginButton.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://chat.openai.com' });
  });

  summarizeButton.addEventListener('click', async () => {
    try {
      loading.classList.remove('hidden');
      summary.classList.add('hidden');

      // Get active tab
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      // Execute content script to extract text
      const [{ result: text }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          return document.body.innerText;
        },
      });

      // Generate summary
      const summarizedText = await client.summarizeText(text);
      
      summaryContent.textContent = summarizedText;
      summary.classList.remove('hidden');
    } catch (error) {
      summaryContent.textContent = chrome.i18n.getMessage('error');
      summary.classList.remove('hidden');
    } finally {
      loading.classList.add('hidden');
    }
  });
});