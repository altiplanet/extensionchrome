export class ChatGPTClient {
  constructor() {
    this.chatgptUrl = 'https://chat.openai.com';
  }

  async checkLoginStatus() {
    try {
      const response = await fetch(`${this.chatgptUrl}/api/auth/session`);
      const data = await response.json();
      return !!data.accessToken;
    } catch (error) {
      console.error('Error checking login status:', error);
      return false;
    }
  }

  async summarizeText(text) {
    if (!await this.checkLoginStatus()) {
      throw new Error('Not logged in to ChatGPT');
    }

    const prompt = `Please summarize the following text concisely:\n\n${text}`;
    
    try {
      // Use ChatGPT's conversation API
      const response = await fetch(`${this.chatgptUrl}/api/conversation`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: [{ role: 'user', content: prompt }],
          model: 'text-davinci-002',
          stream: false,
        }),
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error('Failed to generate summary');
      }

      const data = await response.json();
      return data.choices[0].message.content;
    } catch (error) {
      console.error('Error generating summary:', error);
      throw error;
    }
  }
}