export function extractMainContent(): string {
  const selectors = [
    'article',
    '[role="main"]',
    '.main-content',
    '#main-content',
    'main',
  ];

  for (const selector of selectors) {
    const element = document.querySelector(selector);
    if (element) {
      return cleanText(element.textContent || '');
    }
  }

  return extractUsingHeuristics();
}

function extractUsingHeuristics(): string {
  const elementsToRemove = [
    'header',
    'footer',
    'nav',
    'aside',
    'script',
    'style',
    'noscript',
    'iframe',
    'ad',
    '.advertisement',
  ];

  const tempDoc = document.cloneNode(true) as Document;
  elementsToRemove.forEach(selector => {
    tempDoc.querySelectorAll(selector).forEach(el => el.remove());
  });

  const paragraphs = Array.from(tempDoc.getElementsByTagName('p'))
    .filter(p => (p.textContent || '').length > 50);

  return cleanText(paragraphs.map(p => p.textContent).join('\n'));
}

function cleanText(text: string): string {
  return text
    .replace(/\s+/g, ' ')
    .replace(/\n\s*/g, '\n')
    .trim();
}