export function extractMainContent() {
  // Priority elements to check for main content
  const selectors = [
    'article',
    '[role="main"]',
    '.main-content',
    '#main-content',
    'main',
  ];

  // Try to find content using priority selectors
  for (const selector of selectors) {
    const element = document.querySelector(selector);
    if (element) {
      return cleanText(element.textContent);
    }
  }

  // Fallback: Use readability heuristics
  return extractUsingHeuristics();
}

function extractUsingHeuristics() {
  // Remove unwanted elements
  const elementsToRemove = [
    'header',
    'footer',
    'nav',
    'aside',
    'script',
    'style',
    'noscript',
    'iframe',
    'ad',
    '.advertisement',
  ];

  const tempDoc = document.cloneNode(true);
  elementsToRemove.forEach(selector => {
    tempDoc.querySelectorAll(selector).forEach(el => el.remove());
  });

  // Find paragraphs with substantial content
  const paragraphs = Array.from(tempDoc.getElementsByTagName('p'))
    .filter(p => p.textContent.length > 50);

  return cleanText(paragraphs.map(p => p.textContent).join('\n'));
}

function cleanText(text) {
  return text
    .replace(/\s+/g, ' ')
    .replace(/\n\s*/g, '\n')
    .trim();
}