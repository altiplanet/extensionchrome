// This script runs in the context of web pages
import { extractMainContent } from './utils/textExtractor.js';

// Listen for messages from the popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extractText') {
    const text = extractMainContent();
    sendResponse({ text });
  }
});