import React from 'react';
import { createRoot } from 'react-dom/client';
import { Brain } from 'lucide-react';
import '../index.css';

function Popup() {
  const [isLoggedIn, setIsLoggedIn] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(false);
  const [summary, setSummary] = React.useState('');

  React.useEffect(() => {
    checkLoginStatus();
  }, []);

  const checkLoginStatus = async () => {
    try {
      const response = await fetch('https://chat.openai.com/api/auth/session');
      const data = await response.json();
      setIsLoggedIn(!!data.accessToken);
    } catch (error) {
      setIsLoggedIn(false);
    }
  };

  const handleSummarize = async () => {
    setIsLoading(true);
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const [{ result: text }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id! },
        func: () => document.body.innerText,
      });

      const response = await fetch('https://chat.openai.com/api/conversation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [{ role: 'user', content: `Please summarize:\n\n${text}` }],
          model: 'text-davinci-002',
          stream: false,
        }),
        credentials: 'include',
      });

      if (!response.ok) throw new Error('Failed to generate summary');
      
      const data = await response.json();
      setSummary(data.choices[0].message.content);
    } catch (error) {
      setSummary('Error generating summary');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-[400px] min-h-[200px] p-4">
      <div className="flex items-center gap-3 pb-3 border-b border-gray-200">
        <Brain className="w-6 h-6 text-blue-600" />
        <h1 className="text-lg font-semibold text-gray-900">Content Condenser AI</h1>
      </div>

      {!isLoggedIn ? (
        <div className="mt-4">
          <p className="text-sm text-gray-600 mb-3">
            Please log in to ChatGPT to use this extension
          </p>
          <button
            onClick={() => chrome.tabs.create({ url: 'https://chat.openai.com' })}
            className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            Login to ChatGPT
          </button>
        </div>
      ) : (
        <div className="mt-4">
          <button
            onClick={handleSummarize}
            disabled={isLoading}
            className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors disabled:bg-blue-400"
          >
            {isLoading ? 'Generating...' : 'Summarize'}
          </button>

          {isLoading && (
            <div className="mt-4 flex flex-col items-center">
              <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
              <p className="mt-2 text-sm text-gray-600">Generating summary...</p>
            </div>
          )}

          {summary && !isLoading && (
            <div className="mt-4 p-3 bg-gray-50 rounded-md">
              <p className="text-sm text-gray-800">{summary}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

const root = document.getElementById('root');
if (root) {
  createRoot(root).render(
    <React.StrictMode>
      <Popup />
    </React.StrictMode>
  );
}