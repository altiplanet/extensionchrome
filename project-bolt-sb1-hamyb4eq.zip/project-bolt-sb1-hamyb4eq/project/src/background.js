// Service worker for handling background tasks
chrome.runtime.onInstalled.addListener(() => {
  // Set up context menu
  chrome.contextMenus.create({
    id: 'summarizeSelection',
    title: chrome.i18n.getMessage('summarizeButton'),
    contexts: ['selection'],
  });
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'summarizeSelection') {
    chrome.tabs.sendMessage(tab.id, {
      action: 'summarizeSelection',
      text: info.selectionText,
    });
  }
});