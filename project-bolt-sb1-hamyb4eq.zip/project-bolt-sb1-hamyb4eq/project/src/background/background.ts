chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'summarizeSelection',
    title: chrome.i18n.getMessage('summarizeButton'),
    contexts: ['selection'],
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'summarizeSelection' && tab.id) {
    chrome.tabs.sendMessage(tab.id, {
      action: 'summarizeSelection',
      text: info.selectionText,
    });
  }
});