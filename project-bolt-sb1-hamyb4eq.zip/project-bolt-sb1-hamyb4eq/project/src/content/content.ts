import { extractMainContent } from '../utils/textExtractor';

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extractText') {
    const text = extractMainContent();
    sendResponse({ text });
  }
});